﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Media;
using System.Threading;
using System.IO;

namespace NumberGame_v2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.CursorVisible = false; //Removes the bliking line




            playBackgroundMusic("main");
            drawMenu(new string[] { "Start", "Check highscore", "Exit" }, 0);


        }

        static int[,] getNumbers(int level)
        {
            Random rand = new Random();
            int[,] numbers = new int[10, 2];
            int randMin = 0;
            int randMax = 0;

            switch (level)
            {
                case 1:
                    randMin = 1;
                    randMax = 11;
                    break;
                case 2:
                    randMin = 1;
                    randMax = 101;
                    break;
                case 3:
                    randMin = 1;
                    randMax = 1001;
                    break;
                case 4:
                    randMin = 1;
                    randMax = 10000;
                    break;
                default:
                    break;
            }

            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    numbers[i, j] = rand.Next(randMin, randMax);
                }
            }

            return numbers;

        }


        static int Add(int num1, int num2)
        {
            int result = num1 + num2;

            return result;
        }

        static int Subtraction(int num1, int num2)
        {
            int result = num1 - num2;

            return result;
        }

        static int Multiplication(int num1, int num2)
        {
            int result = num1 * num2;

            return result;
        }

        static int Divide(int num1, int num2)
        {
            int result = num1 / num2;

            return result;
        }

        static int createCalc(string type, int level)
        {
            Console.Clear();
            Console.CursorVisible = true;
            int points = 0;


            int[,] numbers = getNumbers(level);


            for (int i = 0; i < numbers.GetLength(0); i++)
            {

                int attempts = 1;
                bool correct = false;

                while (attempts <= 3 && correct != true)
                {

                    string calculation = numbers[i, 0] + " " + type + " " + numbers[i, 1];
                    int result = 0;
                    int input = getAnswer(calculation);
                    switch (type)
                    {
                        case "+":
                            result = Add(numbers[i, 0], numbers[i, 1]);
                            break;
                        case "-":
                            result = Subtraction(numbers[i, 0], numbers[i, 1]);
                            break;
                        case "*":
                            result = Multiplication(numbers[i, 0], numbers[i, 1]);
                            break;
                        case "/":
                            result = Divide(numbers[i, 0], numbers[i, 1]);
                            break;
                        default:
                            break;
                    }

                    if (result == input)
                    {
                        correct = true;
                        points += level;
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("CORRECT!");
                        Thread.Sleep(1000);
                        Console.ResetColor();

                    }
                    else if (attempts == 3 && correct != true)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        string answer = "The correct answer is: " + result + " to the calculation of " + calculation;
                        Console.WriteLine(answer);
                        Console.WriteLine("Press any button for next.....");
                        Console.ReadKey();
                        Console.ResetColor();


                    }
                    else
                    {
                        int attemptsleft = 3 - attempts;
                        string tryagain = "Try again! Attempts left: " + attemptsleft;
                        Console.WriteLine(tryagain);
                    }

                    attempts++;
                }
                Console.Clear();
            }
            return points;
        }

        static int getAnswer(string calculation)
        {

            int input;
            string text = "What is the result of the calculation: " + calculation + " = ";
            Console.Write(text);
            if (Int32.TryParse(Console.ReadLine(), out input))
                return input;
            else
                throw new ArgumentException("WRONG INPUT");


        }


        public static int drawMenu(string[] menuItems, int headline)
        {


            string[] arr = { "WELCOME", "PICK UR CHOICE", "CHOOSE LVL PLZ", "HIGHSCORE LIST #1337", "U r 1337, want to go in wall of fame?" };
            string type = string.Empty;
            int selectedItem = 0;
            while (true)
            {
                Console.CursorVisible = false;
                Console.Clear();
                Console.WriteLine(arr[headline]);

                for (int i = 0; i < menuItems.Length; i++)
                {

                    if (selectedItem == i)
                    {
                        Console.BackgroundColor = ConsoleColor.Gray;
                        Console.ForegroundColor = ConsoleColor.Black;
                        Console.WriteLine(menuItems[i]);
                        Console.ResetColor();
                    }
                    else
                    {
                        Console.WriteLine(menuItems[i]);
                    }
                }

                ConsoleKeyInfo cki = Console.ReadKey();

                switch (cki.Key)
                {
                    case ConsoleKey.UpArrow:
                        if ((selectedItem - 1) < 0)
                        {
                            selectedItem = menuItems.Length - 1;
                        }
                        else
                        {
                            selectedItem--;
                        }

                        break;
                    case ConsoleKey.DownArrow:
                        if ((selectedItem + 1) > menuItems.Length - 1)
                        {
                            selectedItem = 0;
                        }
                        else
                        {
                            selectedItem++;
                        }
                        break;


                    case ConsoleKey.Enter:
                        //System.Media.SystemSounds.Beep.Play();
                        switch (menuItems[selectedItem])
                        {
                            case "Start":
                                int points = drawMenu(new string[] { "+", "-", "*", "/", "BACK TO MAIN MENU" }, 1);
                                savePoints(points);
                                playBackgroundMusic("main");
                                break;
                            case "Check highscore":
                                Console.Clear();
                                printHighscore();
                                drawMenu(new string[] { "BACK TO MAIN MENU" }, 3);
                                break;
                            case "Exit":
                                Console.Clear();
                                playBackgroundMusic("sad");
                                Console.WriteLine("BYE BYE!");
                                Thread.Sleep(1000);
                                return -100;
                            case "+":
                                type = menuItems[selectedItem];
                                return createCalc(type, drawMenu(new string[] { "1", "2", "3", "4", "BACK TO MAIN MENU" }, 2));
                            case "-":
                                type = menuItems[selectedItem];
                                return createCalc(type, drawMenu(new string[] { "1", "2", "3", "4", "BACK TO MAIN MENU" }, 2));
                            case "*":
                                type = menuItems[selectedItem];
                                return createCalc(type, drawMenu(new string[] { "1", "2", "3", "4", "BACK TO MAIN MENU" }, 2));
                            case "/":
                                type = menuItems[selectedItem];
                                return createCalc(type, drawMenu(new string[] { "1", "2", "3", "4", "BACK TO MAIN MENU" }, 2));
                            case "1":
                                return 1;
                            case "2":
                                return 2;
                            case "3":
                                return 3;
                            case "4":
                                return 4;
                            case "BACK TO MAIN MENU":
                                return -100;
                            case "sure":
                                return 1;
                            case "Naaah":
                                return 0;
                            default:
                                break;
                        }
                        break;
                }
                Console.Clear();
            }
        }

        static void playBackgroundMusic(string song)
        {
            var myPlayer = new System.Media.SoundPlayer();
            if (song == "main")
            {
                myPlayer.Stop();
                myPlayer.SoundLocation = @"C:\Users\Mathias O. Rasmussen\documents\visual studio 2017\Projects\Datatekniker.SDE\NumberGame_v2\Joomla12 - CS4 Multikg.wav";
            }
            else if (song == "sad")
            {
                myPlayer.Stop();
                myPlayer.SoundLocation = @"C:\Users\Mathias O. Rasmussen\documents\visual studio 2017\Projects\Datatekniker.SDE\NumberGame_v2\Bye Bye -SoundBible.com-1483442951.wav";
            }
            else if (song == "win")
            {
                myPlayer.Stop();
                myPlayer.SoundLocation = @"C:\Users\Mathias O. Rasmussen\documents\visual studio 2017\Projects\Datatekniker.SDE\NumberGame_v2\Ta Da-SoundBible.com-1884170640.wav";
            }

            myPlayer.PlayLooping();
        }

        static string savePoints(int points)
        {
            Console.Clear();
            playBackgroundMusic("win");
            Console.WriteLine("NICE! U scored {0} point!", points);
            if (checkForNewRecord(points))
            {
                if (drawMenu(new string[] { "Sure", "Naaah" }, 4) == 1)
                {

                    using (System.IO.StreamWriter file =
                    new System.IO.StreamWriter(@"C:\Users\Mathias O. Rasmussen\Documents\visual studio 2017\Projects\Datatekniker.SDE\NumberGame_v2\HighscoreList.txt", true))
                    {
                        file.WriteLine(points);
                    }
                }
                else
                {
                    return "k";
                }
            }
            Console.ReadKey();
            return "thx";
        }

        static bool checkForNewRecord(int points)
        {

            int better = 0;
            int hit = 0;

            try
            {

                foreach (string record in File.ReadLines(@"C:\Users\Mathias O. Rasmussen\Documents\visual studio 2017\Projects\Datatekniker.SDE\NumberGame_v2\HighscoreList.txt", Encoding.UTF8))
                {
                    if (points >= Convert.ToInt32(record))
                    {
                        better++;

                    }
                    hit++;
                }

            }
            catch (Exception)
            {
                return true;

            }



            if (better > 0 && hit < 10)
            {
                return true;
            }
            else
            {
                return false;
            }



        }

        static void printHighscore()
        {
            Console.WriteLine("HIGHSCORE LIST #1337");
            foreach (string record in File.ReadLines(@"C:\Users\Mathias O. Rasmussen\Documents\visual studio 2017\Projects\Datatekniker.SDE\NumberGame_v2\HighscoreList.txt", Encoding.UTF8))
            {
                Console.WriteLine(record);
            }
            Console.WriteLine("PRESS ANY KEY TO CONTINUE");
            Console.ReadKey();

        }


    }
}
