﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiceThrow
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Amount of dices: ");
            int dices = Int32.Parse(Console.ReadLine());
            int i = 1;
            int[] throws = new int[dices];
            Random rand = new Random();

            do
            {
                Console.WriteLine("Throw {0:D}.... ", i);
                for (int x = 0; x < dices; x++)
                {
                    throws[x] = rand.Next(1, 7);  
                }
                i++;
            } while (!Array.TrueForAll(throws, item => item == 6));
            
            Console.WriteLine("It took {0:D} throws to get {1:D} sixes", i, dices);
            Console.Read();
        }
    }
}
