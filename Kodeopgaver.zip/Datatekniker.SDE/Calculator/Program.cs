﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Media;

namespace Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            

            string welcome = "Welcome to the most reliable calculator!";
            string menuchoose = "Choose what you want: ";
            string menu = "1: Start from zero\n2: Continue with sum\n3: Log\n4: Play a song\n0: Exit";


            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.SetCursorPosition((Console.WindowWidth - welcome.Length) / 2, Console.CursorTop);
            Console.WriteLine(welcome);
            Console.ResetColor();
            Console.Write(new String(' ', Console.BufferWidth));



            int choice;
            bool exit = false;
            double sum = 0;
            List<string> log = new List<string>();
            Array result = new Array[2];




            while (exit == false)
            {
                Console.WriteLine(menu);
                Console.Write(menuchoose);
                choice = Int16.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 0:
                        exit = true;
                        break;
                    case 1:
                        result = Calculator(log);
                        sum = result.GetValue(0);
                        break;
                    case 2:
                        result = Calculator(log, sum);
                        break;
                    case 3:
                        PrintLog(log);
                        break;
                    case 4:
                        SoundPlayer player = new SoundPlayer();
                        player.SoundLocation = AppDomain.CurrentDomain.BaseDirectory + "\\yourmusic.wav";
                        player.Play();
                        break;
                  
                }

                
            }




        }

        static double Add(double num1, double num2)
        {
            double res = num1 + num2;
            return res;
        }

        static double Subtract(double num1, double num2)
        {
            double res = num1 - num2;
            return res;
        }

        static double Multiply(double num1, double num2)
        {
            double res = num1 * num2;
            return res;
        }

        static double Divide(double num1, double num2)
        {
            double res = num1 / num2;
            return res;
        }
        
        static void PrintLog(List<string> i)
        {
            foreach (string calc in i)
            {
                Console.WriteLine(calc);
            }
        }

        static Array Calculator(List<string> log, double sum = 0)
        {
            string numinsert = "Insert number: ";
            string operchoose = "Choose the operator: ";

            double num1 = 0;
            char givenopreator = '.';

            if (sum == 0)
            {
                Console.Write(numinsert);
                num1 = double.Parse(Console.ReadLine());
                Console.Write(operchoose);
                givenopreator = Console.ReadKey().KeyChar;
            }
            else
            {
                num1 = sum;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("SUM = {0}", sum);
                Console.ResetColor();
                Console.Write(operchoose);
                givenopreator = Console.ReadKey().KeyChar;


            }



            Console.Write("\n{0}", numinsert);
            double num2 = double.Parse(Console.ReadLine());


            switch (givenopreator)
            {
                case '+':
                    sum = Add(num1, num2);
                    break;
                case '-':
                    sum = Subtract(num1, num2);
                    break;
                case '*':
                    sum = Multiply(num1, num2);
                    break;
                case '/':
                    sum = Divide(num1, num2);
                    break;

            }

            Console.Clear();
            string tolog = num1.ToString() + givenopreator.ToString() + num2.ToString() + "=" + sum.ToString();
            Console.WriteLine("Result: {0:G} {1} {2:G} = {3:G}", num1, givenopreator, num2, sum);

            return sum;

        }

        static string StringForLog(double num1, double num2, char oper)
        {
            return num1.ToString() + oper.ToString() + num2.ToString() + "=";
        }
    }
}
