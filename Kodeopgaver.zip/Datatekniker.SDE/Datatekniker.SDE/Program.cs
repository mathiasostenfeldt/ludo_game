﻿using System;
using System.Speech.Synthesis;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datatekniker.SDE
{
    class Program
    {
        static void Main(string[] args)
        {
            string firstname;
            string lastname;
            int age = 0;
            int old;
            int diff;
            int year = DateTime.Now.Year;
            string gender = "";
            SpeechSynthesizer speech = new SpeechSynthesizer();
            

            Console.Write("Firstname: ");
            firstname = Console.ReadLine();
            Console.Write("Lastname: ");
            lastname = Console.ReadLine();
            
            bool correct;
            do {
                    Console.Write("Age: ");
                    string input;
                    input = Console.ReadLine();
                    correct = int.TryParse(input, out age);
            }
            while (!correct);



            correct = false;
            while(correct == false)
            {
                char genChar;
                Console.Write("Gender M/W: ");
                genChar = Console.ReadKey().KeyChar;

                if ( genChar == 'M' || genChar == 'm')
                {
                    gender = "man";
                    correct = true;
                }
                else if (genChar == 'W' || genChar == 'w')
                {
                    gender = "woman";
                    correct = true;
                }
                else
                {
                    Console.WriteLine("\nYou can only type a char... M/m == Man OR W/w == Woman!!!");
                }

            }
            
            

            Console.Clear();


            correct = false;
            do
            {
                Console.Write("In your opinion, when are a person old: ");
                string input = Console.ReadLine();
                correct = int.TryParse(input, out old);
            }
            while (!correct);
            
            

            Console.Clear();

            diff = old - age;

            if (age < old)
            {
                
                Console.WriteLine("You are not old yet!!");
                speech.Speak("You are not old yet!!");
                Console.WriteLine("There is " + diff + " years left until you're an old " + gender);
                speech.Speak("There is " + diff + " years left until you're an old " + gender);
                Console.WriteLine("In the year: " + (diff + year) + " you will be an old " + gender);
                speech.Speak("In the year: " + (diff + year) + " you will be an old " + gender);
            }
            else if(age >= old)
            {
                Console.WriteLine("You're already an old" + gender + "!!!");
                speech.Speak("You're already an old" + gender + "!!!");
            }
            else
            {
                Console.WriteLine("Something went wrong...");
            }

            Console.Read();
            
        }
    }
}
