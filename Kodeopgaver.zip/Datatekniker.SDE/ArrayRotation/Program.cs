﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayRotation
{
    class Program
    {
        static void Main(string[] args)
        {
            //testmethod(100);
            //testmethod(100, 5);
            testmethod(1, 3, 1);
            Console.ReadKey();
        }

        static Array Rotate(Array A, int K)
        {
            
            if (A.Length < 0 || A.Length > 100)
            {
                throw new ArgumentException("N is out of scope. Array size given: " + A.Length);
            }
            if (K < 0 || K > 100)
            {
                throw new ArgumentException("K is out of scope. Amount of rotations given: " + K);
            }

            foreach (int number in A)
            {
                if (number < -1000 || number > 1000)
                {
                    throw new ArgumentException("Element in A is out of scope. Value: " + number);
                }
            }
            
            for (int i = 0; i < K; i++)
            {
                int current = 0;
                int next = 0;
                for (int x = 0; x < A.Length; x++)
                {
                    if (x == 0)
                    {
                        if (!(A.Length <= 1))
                        {
                            current = Int32.Parse(A.GetValue(x).ToString());
                            next = Int32.Parse(A.GetValue(x + 1).ToString());
                            A.SetValue(current, x + 1);
                        }
                    }
                    else if (x + 1 == A.Length)
                    {                       
                        current = next;
                        next = Int32.Parse(A.GetValue(0).ToString());
                        A.SetValue(current, 0);
                    }
                    else if (x == A.Length)
                    {                     
                        A.SetValue(next, 0);
                    }
                    else
                    {                        
                        current = next;
                        next = Int32.Parse(A.GetValue(x + 1).ToString());
                        A.SetValue(current, x + 1);
                    }
                }
            }

            return A;
        }


        static void testmethod(int loop)
        {
            Random rand = new Random();
            int countfail = 0;
            

            
            for (int i = 0; i < loop; i++)
            {
                int arraysize = rand.Next(1,100);
                int[] A = new int[arraysize];
                int intmin = -1000;
                int intmax = 1000;
                int K = rand.Next(0, 100);


                for (int x = 0; x < A.Length; x++)
                {
                   A[x] = rand.Next(intmin, intmax);
                }
                try
                {
                    Rotate(A, K);
                    Console.WriteLine("Success! Loop: " + i);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.ReadKey();
                    countfail++;
                }

            }
            
            Console.WriteLine("Test failed {0:D} times out of {1:D}", countfail, loop); 
        }

        static void testmethod(int loop, int arraysize)
        {
            Random rand = new Random();
            int countfail = 0;



            for (int i = 0; i < loop; i++)
            {
                
                int[] A = new int[arraysize];
                int intmin = -1000;
                int intmax = 1000;
                int K = rand.Next(0, 100);


                for (int x = 0; x < A.Length; x++)
                {
                    A[x] = rand.Next(intmin, intmax);
                }
                try
                {
                    Rotate(A, K);
                    Console.WriteLine("Success! Loop: " + i + " Arraysize: " + arraysize);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.ReadKey();
                    countfail++;
                }

            }
            
            Console.WriteLine("Test failed {0:D} times out of {1:D}", countfail, loop);
        }

        static void testmethod(int loop, int arraysize, int moves)
        {
            Random rand = new Random();
            int countfail = 0;



            for (int i = 0; i < loop; i++)
            {
                int[] A = new int[arraysize];
                int intmin = -1000;
                int intmax = 1000;
                int K = moves;


                for (int x = 0; x < A.Length; x++)
                {
                    A[x] = rand.Next(intmin, intmax);
                }
                try
                {
                    string a = string.Empty;
                    foreach (int item in A)
                    {
                        a += item.ToString() + " ";
                    }

                    Array B = Rotate(A, K);

                    string b = string.Empty;
                    foreach (int item in B)
                    {
                        b += item.ToString() + " ";
                    }

                    Console.WriteLine("Success - " + a + " moved: " + K + " times. Result: " + b);

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.ReadKey();
                    countfail++;
                }

            }
            
            Console.WriteLine("Test failed {0:D} times out of {1:D}", countfail, loop);

        }

        static void testmethod(int loop, int arraysize, int moves, int arrminval, int arrmaxval)
        {
            Random rand = new Random();
            int countfail = 0;



            for (int i = 0; i < loop; i++)
            {
                int[] A = new int[arraysize];
                int intmin = arrminval;
                int intmax = arrmaxval;
                int K = moves;


                for (int x = 0; x < A.Length; x++)
                {
                    A[x] = rand.Next(intmin, intmax);
                }
                try
                {
                    string a = string.Empty;
                    foreach (int item in A)
                    {
                        a += item.ToString() + " ";
                    }

                    Array B = Rotate(A, K);

                    string b = string.Empty;
                    foreach (int item in B)
                    {
                        b += item.ToString() + " ";
                    }

                    Console.WriteLine("Success - " + a + " moved: " + K + " times. Result: " + b);

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.ReadKey();
                    countfail++;
                }

            }

            Console.WriteLine("Test failed {0:D} times out of {1:D}", countfail, loop);

        }

    }
}
