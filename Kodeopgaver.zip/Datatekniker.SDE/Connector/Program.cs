﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System

namespace Connector
{
    class Program
    {
        static void Main(string[] args)
        {



            int program = 0;


            switch (program)
            {
                case 1:
                    
                    break;
                default:
                    break;
            }
        }
    }
}
