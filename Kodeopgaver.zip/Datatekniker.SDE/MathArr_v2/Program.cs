﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace MatchArr
{
    class Program
    {
        static void Main(string[] args)
        {
           
            try
            {
                const int m = 1000000;
                Stopwatch s1 = Stopwatch.StartNew();
                for (int i = 0; i < m; i++)
                {
                    int[] A = { 2, 2, 2, 2, 1, 1, 1, 1, 3 };
                    MatchArr(A);
                }
                s1.Stop();
                Stopwatch s2 = Stopwatch.StartNew();
                for (int i = 0; i < m; i++)
                {
                    int[] A = { 2, 2, 2, 2, 1, 1, 1, 1, 3 };
                    MatchArr(A);
                }
                s2.Stop();
                Stopwatch s3 = Stopwatch.StartNew();
                for (int i = 0; i < m; i++)
                {
                    int[] A = { 2, 2, 2, 2, 1, 1, 1, 1, 3 };
                    MatchArr(A);
                }
                s3.Stop();
                Console.WriteLine("{0},{1},{2}",
                    s1.ElapsedMilliseconds,
                    s2.ElapsedMilliseconds,
                    s3.ElapsedMilliseconds);

            }
            catch (Exception e)
            {

                Console.WriteLine(e.Message);
            }
           
            Console.Read();
        



        /*
        int[] A = { 2, 2, 2, 1, 1, 1, 1 };
        testmethod(101, 1, 4, 100);
        int i = MatchArr(A);

        Console.WriteLine(i);
        Console.ReadKey();
        */

    }

        static int MatchArr(int[] A)
        {
            int leftOver = 0;

            if (IsEven(A.Length))
                throw new ArgumentException("Array is not uneven");

            if (A.Length < 1 || A.Length >= 1000000)
                throw new ArgumentException("Array length i out of scope");

            foreach (int item in A)
            {
                if (item < 1 || item > 1000000000)
                    throw new ArgumentException("Element is out of scope!");
            }
            
            
            bool onlyone = true;

            for (int i = 0; i < A.Length; i++)
            {
                for (int x = 0; x < A.Length; x++)
                {
                    if (A[x] != 0 || A[i] != 0)
                    {
                        if (A[x] == A[i] && x != i)
                        {
                            A.SetValue(0, x);
                            A.SetValue(0, i);
                        }
                    }
                }
                if (A[i] != 0 && onlyone == true)
                {
                    leftOver = A[i];
                    onlyone = false;
                }
                else if(onlyone == false && A[i] != leftOver && A[i] != 0)
                {
                  throw new ArgumentException("Multiple single numbers");
                }
            }
            //Console.WriteLine(leftOver + " is missing a partner!");
            return leftOver;
        }

        public static bool IsEven(int value)
        {
            return value % 2 == 0;
        }

        static void testmethod(int ArrSize, int ArrElemMin, int ArrElemMax)
        {
            Random rand = new Random();
            int[] A = new int[ArrSize];

            try
            {
                for (int x = 0; x < A.Length; x++)
                {
                    A[x] = rand.Next(ArrElemMin, ArrElemMax);
                }

                MatchArr(A);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();
        }

        static void testmethod(int ArrSize, int ArrElemMin, int ArrElemMax, int Loop)
        {
            Random rand = new Random();
            int[] A = new int[ArrSize];
            int hit = 0;
            int fail = 0;


            for (int i = 0; i < Loop; i++)
            {
                hit++;
                try
                {
                    for (int x = 0; x < A.Length; x++)
                    {
                        A[x] = rand.Next(ArrElemMin, ArrElemMax);
                    }
                    MatchArr(A);
                }
                catch (Exception e)
                {
                    fail++;
                    Console.WriteLine(e.Message);
                }
            }

           Console.WriteLine("Tested {0:D} times (expected: {1:D}), with {2:D} fails", hit, Loop, fail);
            Console.WriteLine("Tested with these parameters: Arraysize = {0:D}, Array element= MIN({1:D}) - MAX({2:D}), testloops = {3:D}", ArrSize, ArrElemMin, ArrElemMax, Loop);
            Console.ReadKey();
            
        }
    }
}
