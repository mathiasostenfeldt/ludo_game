﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Calculator_v2
{
    class Program
    {


        static void Main(string[] args)
        {

            bool exit = false;
            int choice = 0;
            double sum = 0;
            List<string> log = new List<string>();


            while (exit == false)
            {

                string menu = "1: Start from zero\n" +
                              "2: Start with result from last calculation\n" +
                              "3: Print log\n" +
                              "4: Convert number to binary\n" +
                              "5: Get square root\n" +
                              "0: Exit";

                Console.WriteLine(menu);
                Console.Write("Choose a menu: ");
                bool valid = Int32.TryParse(Console.ReadLine(), out choice);
                Console.WriteLine(choice);




                try
                {
                    Console.Clear();
                    
                    if (!valid)
                    {
                        throw new ArgumentException("Wrong input");
                    }
                    

                    switch (choice)
                    {
                        case 1:
                            sum = Calculate();
                            break;
                        case 2:
                            sum = Calculate(sum);
                            break;
                        case 3:
                            PrintLog();
                            break;
                        case 4:
                            ConvertToBinary();
                            break;
                        case 5:
                            Sqrt();
                            break;
                        case 0:
                            exit = true;
                            break;
                        default:
                            break;
                    }

                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);
                }
               

            }

            File.Delete(@"C:\Users\Mathias O. Rasmussen\Documents\visual studio 2017\Projects\Datatekniker.SDE\Calculator_v2\bin\CalcLog.txt");
        }

        static double Calculate(double sum = 0)
        {
            string[] options = { "+", "-", "*", "/", "^" };
            Console.Clear();
            string numinsert = "Insert number: ";
            string operchoose = "Choose the operator: ";
            bool numIsTrue = false;


            double num1 = 0;
            string givenopreator = string.Empty;

            if (sum == 0)
            {
                numIsTrue = false;
                while (numIsTrue == false)
                {
                    Console.Write(numinsert);
                    string data = Console.ReadLine();
                    Console.Clear();
                    if (IsNumeric(data))
                    {
                        num1 = double.Parse(data);
                        numIsTrue = true;
                    }
                }


                while (!options.Contains(givenopreator))
                {
                    Console.Clear();
                    Console.Write(operchoose);
                    givenopreator = Console.ReadLine();

                }
            }
            else
            {
                num1 = sum;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("SUM = {0}", sum);
                Console.ResetColor();
                while (!options.Contains(givenopreator))
                {
                    Console.Clear();
                    Console.Write(operchoose);
                    givenopreator = Console.ReadLine();

                }


            }


            double num2 = 0;
            numIsTrue = false;
            while (numIsTrue == false)
            {
                Console.Clear();
                Console.Write(numinsert);
                string data = Console.ReadLine();
                Console.Clear();
                if (IsNumeric(data))
                {
                    num2 = double.Parse(data);
                    numIsTrue = true;
                }
            }

            try
            {

                switch (givenopreator)
                {
                    case "+":
                        sum = Add(num1, num2);
                        break;
                    case "-":
                        sum = Subtract(num1, num2);
                        break;
                    case "*":
                        sum = Multiply(num1, num2);
                        break;
                    case "/":
                        sum = Divide(num1, num2);
                        break;
                    case "^":
                        sum = Power(num1, num2);
                        break;

                }

                string tolog = num1.ToString() + givenopreator.ToString() + num2.ToString() + "=" + sum.ToString();
                WriteToLog(tolog);




                Console.WriteLine("Result: {0:G} {1} {2:G} = {3:G}", num1, givenopreator, num2, sum);

                return sum;

            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return sum = 0;
            }
            

           // Console.Clear();
            

        }

        static double Add(double num1, double num2)
        {
            double res = num1 + num2;
            return res;
        }

        static double Subtract(double num1, double num2)
        {
            double res = num1 - num2;
            return res;
        }

        static double Multiply(double num1, double num2)
        {
            double res = num1 * num2;
            return res;
        }

        static double Divide(double num1, double num2)
        {
            double res = 0;

            if (num1 > 0 && num2 > 0)
            {
                res = num1 / num2;
             
            }
            else if(num1 == 0 || num2 == 0)
            {
               throw new DivideByZeroException("You can't divide with zero!");
            }
            else if(num1 < 0 || num2 < 0)
            {
                throw new ArgumentException("Can't divide with negative numbers!");
            }

            return res;
        }

        static double Power(double num1, double num2)
        {
            double res = Math.Pow(num1, num2);
            return res;
        }

        static double Sqrt()
        {
            Console.Write("Type number you want the square root of: ");
            string data = Console.ReadLine();
            string error = string.Empty;
            double res = 0;
            Console.Clear();
            
                if (!IsNumeric(data))
                    throw new ArgumentException("Invalid Value - This is not a numeric value");
                else
                {
                    res = Math.Sqrt(double.Parse(data));
                    string toLog = "Sqaure root of " + data + " is " + res;
                    Console.WriteLine("Sqaure root of " + data + " is " + res);
                    WriteToLog(toLog);
                }
            
            return res;
        }

        static string ConvertToBinary()
        {

            Console.Clear();

            Console.Write("Type number you want to convert: ");
            string data = Console.ReadLine();
            int rem = 0;
            string binary = string.Empty;
            string error = string.Empty;
            int num = 0;

                if (!IsNumeric(data))
                    throw new ArgumentException("Invalid Value - This is not a numeric value");
                else
                {
                    int number = int.Parse(data);
                    num = number;

                    while (number > 0)
                    {
                        rem = number % 2;
                        number = number / 2;
                        binary = rem.ToString() + binary;
                    }
                }
           
            Console.Clear();
            string toLog = num + " in binary is: " + binary;
            WriteToLog(toLog);
            Console.WriteLine("{0} in binary is: {1}", num, binary);

            return binary;

        }

        static void WriteToLog(string logstr)
        {
            using (StreamWriter file =
            new StreamWriter(@"C:\Users\Mathias O. Rasmussen\Documents\visual studio 2017\Projects\Datatekniker.SDE\Calculator_v2\bin\CalcLog.txt", true))
            {
                file.WriteLine(logstr);
            }
        }

        static void PrintLog()
        {
            Console.Clear();
            try
            {

                foreach (string line in File.ReadLines(@"C:\Users\Mathias O. Rasmussen\Documents\visual studio 2017\Projects\Datatekniker.SDE\Calculator_v2\bin\CalcLog.txt", Encoding.UTF8))
                {
                    Console.WriteLine(line);
                }

            }
            catch (Exception)
            {

                Console.WriteLine("No file to read!");
            }

        }

        static bool IsNumeric(string input)
        {
            int test;
            return int.TryParse(input, out test);
        }
    }
}
